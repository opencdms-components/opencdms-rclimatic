gg_data <- function(p) {
  ggplot_build(p)$data
}
