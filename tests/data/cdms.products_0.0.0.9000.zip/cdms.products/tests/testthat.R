library(testthat)
library(cdms.products)

test_check("cdms.products")
